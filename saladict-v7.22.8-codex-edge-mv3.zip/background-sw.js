self.window = self;
self.global = self;
importScripts("assets/browser-polyfill.min.js", "assets/runtime.2292bcac.js", "assets/vendor-dompurify.29eab9d9.js", "assets/vendor-react.f788267f.js", "assets/franc.cb74ebcd.js", "assets/vendor-dexie.006b888a.js", "assets/background.2b4b5025.js");