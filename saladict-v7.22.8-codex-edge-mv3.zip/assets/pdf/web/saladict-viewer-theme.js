
;(function () {
  var darkMode = null
  var prefs = {}
  var prefsText = null

  try {
    darkMode = localStorage.getItem('saladict-pdf-viewer-dark-mode')
    prefsText = localStorage.getItem('pdfjs.preferences')
  } catch (error) {
    darkMode = null
    prefsText = null
  }

  if (darkMode !== '0' && darkMode !== '1' && darkMode !== 'follow') {
    return
  }

  if (prefsText) {
    try {
      prefs = JSON.parse(prefsText) || {}
    } catch (error) {
      prefs = {}
    }
  }

  prefs.viewerCssTheme = darkMode === 'follow' ? 0 : darkMode === '1' ? 2 : 1

  try {
    localStorage.setItem('pdfjs.preferences', JSON.stringify(prefs))
  } catch (error) {
    /* ignore localStorage failures */
  }
})()
